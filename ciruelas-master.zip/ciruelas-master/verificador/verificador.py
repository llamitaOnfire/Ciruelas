# Implementa el veficador de ciruelas
# Se refiere a Vara(s) a cada item o elemento

from utils.árbol import ÁrbolSintáxisAbstracta, NodoÁrbol, TipoNodo
from utils.tipo_datos import TipoDatos

class TablaSimbolos:
    
    # Almacena información auxiliar para decorar el árbol de sintaxis abstracta con información de tipo y alcance.
    # La estructura de símbolos es una lista de diccionarios 


    def __init__(self):
        self.profundidad = 0
        self.simbolos = []
        self.errores = []

    def abrir_bloque(self):
        # Inicia un bloque de alcance (scope)
        self.profundidad += 1

    def cerrar_bloque(self):
        # Termina un bloque de alcance y elimina todos los registros en ese bloque
        self.simbolos = [registro for registro in self.simbolos if registro['profundidad'] != self.profundidad]
        self.profundidad -= 1

    def nuevo_registro(self, nodo, nombre_registro=''):
        # Introduce un nuevo registro a la tabla de símbolos
        diccionario = {
            'nombre': nodo.contenido,
            'profundidad': self.profundidad,
            'referencia': nodo
        }
        self.simbolos.append(diccionario)

    def verificar_existencia(self, nombre):
        # Verifica si un identificador existe como variable/función global o local
        for registro in self.simbolos:
            if registro['nombre'] == nombre and registro['profundidad'] <= self.profundidad:
                return registro
        self.errores.append(f'Esta variable o función no fue declarada correctamente: {nombre}')
        return None

    def __str__(self):
        resultado = 'TABLA DE SÍMBOLOS\n\n'
        resultado += 'Profundidad: ' + str(self.profundidad) + '\n\n'
        for registro in self.simbolos:
            resultado += str(registro) + '\n'
        return resultado

    def obtener_errores(self):
        # Devuelve la lista de errores acumulados
        return self.errores


class Visitante:
    def __init__(self, nueva_tabla_simbolos):
        self.tabla_simbolos = nueva_tabla_simbolos
        self.errores = []

    def visitar(self, nodo):
        # Analiza un nodo y llama al método de visita adecuado
        visit_method = getattr(self, f"_Visitante__visitar_{nodo.tipo.name.lower()}", None)
        if visit_method:
            visit_method(nodo)
        else:
            self.errores.append(f'No existe un método para visitar nodos de tipo: {nodo.tipo}')
            return None

    # Funciones relacionadas con listas

    def __lista(self, nodo_actual):
        # Lista ::= [varaLista]
        # Analiza una lista y asigna el tipo LISTA.
        if len(nodo_actual.nodos) == 0:
            nodo_actual.atributos['tipo'] = TipoDatos.LISTA
            return
        if len(nodo_actual.nodos) != 1 or nodo_actual.nodos[0].tipo != TipoNodo.vara_LISTA:
            self.errores.append("La lista debe contener un único vara de tipo vara_LISTA o estar vacía")
            return
        self.__vara_en_lista(nodo_actual.nodos[0])
        nodo_actual.atributos['tipo'] = TipoDatos.LISTA

    def __vara_en_lista(self, nodo_actual):
        # varaLista ::= Valor (, Valor)*
        # Analiza los elementos de una lista y verifica su tipo.
        for nodo in nodo_actual.nodos:
            if nodo.tipo == TipoNodo.IDENTIFICADOR:
                registro = self.tabla_simbolos.verificar_existencia(nodo.contenido)
                if registro is None:
                    self.errores.append(f"El identificador '{nodo.contenido}' no existe.")
                    return
                nodo.atributos['tipo'] = registro['referencia'].atributos['tipo']
            elif nodo.tipo == TipoNodo.TEXTO or nodo.tipo == TipoNodo.ENTERO:
                nodo.visitar(self)
            else:
                self.errores.append(f"Tipo de nodo '{nodo.tipo}' no válido en un vara de lista.")
        nodo_actual.atributos['tipo'] = TipoDatos.LISTA_vara

    def __entrada_en_lista(self, nodo_actual):
        # ingresoLista ::= Identificador [ Expresion ]
        # Analiza el ingreso a una lista, verifica el identificador y el índice.
        if len(nodo_actual.nodos) != 2 or nodo_actual.nodos[0].tipo != TipoNodo.IDENTIFICADOR or nodo_actual.nodos[1].tipo != TipoNodo.EXPRESION:
            self.errores.append("ingreso a lista mal formado, debe tener un identificador y una expresión.")
            return

        identificador = nodo_actual.nodos[0]
        expresion = nodo_actual.nodos[1]
        registro = self.tabla_simbolos.verificar_existencia(identificador.contenido)
        if registro is None:
            self.errores.append(f"El identificador '{identificador.contenido}' no existe.")
            return
        if registro['referencia'].atributos['tipo'] != TipoDatos.LISTA:
            self.errores.append(f"El identificador '{identificador.contenido}' no es una lista.")
            return

        identificador.atributos['tipo'] = TipoDatos.LISTA
        nodo = self.__visitar_expresion_matematica(expresion)
        if nodo.tipo != TipoNodo.ENTERO:
            self.errores.append(f"El índice de ingreso a una lista debe ser un número, se uso: TEXTO")
            return
        expresion.atributos['tipo'] = TipoDatos.número
        nodo_actual.atributos['tipo'] = TipoDatos.LISTA_vara

    # Funciones relacionadas con otros nodos
    def __visitar_programa(self, nodo_actual):
        # Programa ::= (Comentario | Asignacion | Funcion)* Principal
        for nodo in nodo_actual.nodos:
            nodo.visitar(self)

    def __visitar_asignacion(self, nodo_actual):
        # Asignacion ::= Identificador metale (Identificador | Literal | ExpresionMatematica | Invocacion)
        self.tabla_simbolos.nuevo_registro(nodo_actual.nodos[0])
        for nodo in nodo_actual.nodos:
            nodo.visitar(self)
        nodo_actual.atributos['tipo'] = nodo_actual.nodos[1].atributos.get('tipo', TipoDatos.CUALQUIERA)
        nodo_actual.nodos[0].atributos['tipo'] = nodo_actual.atributos['tipo']

    def __visitar_expresion_matematica(self, nodo_actual):
        # ExpresionMatematica ::= (Expresion) | número | Identificador
        contiene_texto = False
        for nodo in nodo_actual.nodos:
            if nodo.tipo == TipoNodo.IDENTIFICADOR:
                registro = self.tabla_simbolos.verificar_existencia(nodo.contenido)
                if registro is None:
                    return
                nodo.atributos['tipo'] = registro['referencia'].atributos['tipo']
                if nodo.atributos['tipo'] == TipoDatos.TEXTO:
                    self.errores.append(f"Debería ser un número: {nodo.contenido}")
                    contiene_texto = True
            elif nodo.tipo == TipoNodo.TEXTO:
                self.errores.append(f"Debería un número: {nodo.contenido}")
                contiene_texto = True
            elif nodo.tipo == TipoNodo.EXPRESION:
                self.__visitar_expresion_matematica(nodo)
            else:
                nodo.visitar(self)
        nodo_actual.atributos['tipo'] = TipoDatos.TEXTO if contiene_texto else TipoDatos.número

    def __visitar_expresion(self, nodo_actual):
        # Expresion ::= ExpresionMatematica Operador ExpresionMatematica
        for nodo in nodo_actual.nodos:
            nodo.visitar(self)
        nodo_actual.atributos['tipo'] = TipoDatos.número

    def __visitar_funcion(self, nodo_actual):
        # Funcion ::= (Comentario)? mae Identificador (ParametrosFuncion) BloqueInstrucciones
        self.tabla_simbolos.nuevo_registro(nodo_actual)
        self.tabla_simbolos.abrir_bloque()
        for nodo in nodo_actual.nodos:
            nodo.visitar(self)
        self.tabla_simbolos.cerrar_bloque()
        nodo_actual.atributos['tipo'] = nodo_actual.nodos[2].atributos['tipo']

    def __visitar_invocacion(self, nodo_actual):
        # Invocacion ::= Identificador ( ParametrosInvocacion )
        registro = self.tabla_simbolos.verificar_existencia(nodo_actual.nodos[0].contenido)
        if registro is None:
            return
        if registro['referencia'].tipo != TipoNodo.FUNCION:
            self.errores.append(f'Esto es una variable, no función: {registro}')
        for nodo in nodo_actual.nodos:
            nodo.visitar(self)
        nodo_actual.atributos['tipo'] = registro['referencia'].atributos['tipo']

    def __visitar_parametros_invocacion(self, nodo_actual):
        # ParametrosInvocacion ::= Valor (/ Valor)+
        for nodo in nodo_actual.nodos:
            if nodo.tipo == TipoNodo.IDENTIFICADOR:
                self.tabla_simbolos.verificar_existencia(nodo.contenido)
            elif nodo.tipo == TipoNodo.FUNCION:
                self.errores.append(f'Esto es una función: {nodo.contenido}')
            nodo.visitar(self)

    def __visitar_parametros_funcion(self, nodo_actual):
        # ParametrosFuncion ::= Identificador (/ Identificador)+
        for nodo in nodo_actual.nodos:
            self.tabla_simbolos.nuevo_registro(nodo)
            nodo.visitar(self)

    def __visitar_instruccion(self, nodo_actual):
        # Instruccion ::= (Repeticion | Bifurcacion | (Asignacion | Invocacion) | Retorno | Error | Comentario)
        nodo_actual.nodos[0].visitar(self)

    def __visitar_repeticion(self, nodo_actual):
        # Repeticion ::= upee Negacion? (Condicion) BloqueInstrucciones
        index = 0
        if nodo_actual.nodos[index].tipo == TipoNodo.NEGACION:
            self.__visitar_negacion(nodo_actual.nodos[index])
            index += 1
        self.__visitar_condicion(nodo_actual.nodos[index])
        index += 1
        self.tabla_simbolos.abrir_bloque()
        for nodo in nodo_actual.nodos[index:]:
            nodo.visitar(self)
        self.tabla_simbolos.cerrar_bloque()
        nodo_actual.atributos['tipo'] = nodo_actual.nodos[index].atributos['tipo']

    def __visitar_bifurcacion(self, nodo_actual):
        # Bifurcacion ::= DiaySi (Sino)?
        for nodo in nodo_actual.nodos:
            nodo.visitar(self)
        nodo_actual.atributos['tipo'] = TipoDatos.NINGUNO

    def __visitar_diaysi(self, nodo_actual):
        # DiaySi ::= diaysiii Negacion? (Condicion) BloqueInstrucciones (Sino)?
        for nodo in nodo_actual.nodos:
            if nodo.tipo == TipoNodo.NEGACION:
                self.__visitar_negacion(nodo)
            elif nodo.tipo == TipoNodo.CONDICION:
                self.__visitar_condicion(nodo)
        self.tabla_simbolos.abrir_bloque()
        for nodo in nodo_actual.nodos:
            if nodo.tipo == TipoNodo.BLOQUE_INSTRUCCIONES:
                nodo.visitar(self)
            elif nodo.tipo == TipoNodo.SINO:
                self.__visitar_sino(nodo)
        self.tabla_simbolos.cerrar_bloque()
        nodo_actual.atributos['tipo'] = nodo_actual.nodos[0].atributos['tipo']

    def __visitar_sino(self, nodo_actual):
        # Sino ::= sino Negacion? BloqueInstrucciones
        for nodo in nodo_actual.nodos:
            if nodo.tipo == TipoNodo.NEGACION:
                self.__visitar_negacion(nodo)
        self.tabla_simbolos.abrir_bloque()
        for nodo in nodo_actual.nodos:
            if nodo.tipo != TipoNodo.NEGACION:
                nodo.visitar(self)
        self.tabla_simbolos.cerrar_bloque()
        nodo_actual.atributos['tipo'] = TipoDatos.NINGUNO

    def __visitar_condicion(self, nodo_actual):
        # Condicion ::= Comparacion ((divorcio|casorio) Comparacion)? | _enLista
        for nodo in nodo_actual.nodos:
            nodo.visitar(self)
        nodo_actual.atributos['tipo'] = TipoDatos.VALOR_VERDAD

    def __visitar_comparacion(self, nodo_actual):
        # Comparacion ::= Valor Comparador Valor
        registro1, registro2 = None, None
        for i, nodo in enumerate(nodo_actual.nodos):
            if nodo.tipo == TipoNodo.IDENTIFICADOR:
                if i == 0:
                    registro1 = self.tabla_simbolos.verificar_existencia(nodo.contenido)
                    if registro1 is None:
                        return
                elif i == 2:
                    registro2 = self.tabla_simbolos.verificar_existencia(nodo.contenido)
                    if registro2 is None:
                        return
            nodo.visitar(self)
        vara_izq = registro1['referencia'] if nodo_actual.nodos[0].tipo == TipoNodo.IDENTIFICADOR else nodo_actual.nodos[0]
        vara_der = registro2['referencia'] if nodo_actual.nodos[2].tipo == TipoNodo.IDENTIFICADOR else nodo_actual.nodos[2]
        if vara_izq.atributos['tipo'] == vara_der.atributos['tipo']:
            nodo_actual.atributos['tipo'] = TipoDatos.VALOR_VERDAD
        elif vara_izq.atributos['tipo'] == TipoDatos.CUALQUIERA or vara_der.atributos['tipo'] == TipoDatos.CUALQUIERA:
            nodo_actual.atributos['tipo'] = TipoDatos.VALOR_VERDAD
        else:
            self.errores.append(f'Error de tipos en comparación: {nodo_actual}')

    def __visitar_retorno(self, nodo_actual):
        # Retorno ::= sarpe (Valor)?
        for nodo in nodo_actual.nodos:
            nodo.visitar(self)
        if nodo_actual.nodos:
            nodo_actual.atributos['tipo'] = nodo_actual.nodos[0].atributos['tipo']
        else:
            nodo_actual.atributos['tipo'] = TipoDatos.NINGUNO

    def __visitar_error(self, nodo_actual):
        # Error ::= safis Valor
        for nodo in nodo_actual.nodos:
            if nodo.tipo == TipoNodo.IDENTIFICADOR:
                self.tabla_simbolos.verificar_existencia(nodo.contenido)
        nodo_actual.atributos['tipo'] = TipoDatos.NINGUNO

    def __visitar_principal(self, nodo_actual):
        # Principal ::= (Comentario)? (jefe | jefa) mae BloqueInstrucciones
        for nodo in nodo_actual.nodos:
            nodo.visitar(self)
        nodo_actual.atributos['tipo'] = nodo_actual.nodos[0].atributos['tipo']

    def __visitar_bloque_instrucciones(self, nodo_actual):
        # BloqueInstrucciones ::= { Instruccion+ }
        for nodo in nodo_actual.nodos:
            nodo.visitar(self)
        nodo_actual.atributos['tipo'] = next((nodo.atributos['tipo'] for nodo in nodo_actual.nodos if nodo.atributos.get('tipo') != TipoDatos.NINGUNO), TipoDatos.NINGUNO)

    def __visitar_operador(self, nodo_actual):
        # Operador ::= (echele | quitele | chuncherequee | desmadeje)
        nodo_actual.atributos['tipo'] = TipoDatos.número

    def __visitar_valor_verdad(self, nodo_actual):
        # ValorVerdad ::= (True | False)
        nodo_actual.atributos['tipo'] = TipoDatos.VALOR_VERDAD

    def __visitar_comparador(self, nodo_actual):
        # Comparador ::= (cañazo | poquitico | misma vara | otra vara | menos o igualitico | más o igualitico)
        nodo_actual.atributos['tipo'] = TipoDatos.número if nodo_actual.contenido not in ['misma vara', 'otra vara'] else TipoDatos.CUALQUIERA

    def __visitar_negacion(self, nodo_actual):
        # Negacion ::= no
        for nodo in nodo_actual.nodos:
            nodo.visitar(self)
        nodo_actual.atributos['tipo'] = TipoDatos.VALOR_VERDAD

    def __visitarExisiste_enLista(self, nodo_actual):
        # _enLista ::= Valor aentro Lista
        for nodo in nodo_actual.nodos:
            nodo.visitar(self)
        nodo_actual.atributos['tipo'] = TipoDatos.VALOR_VERDAD

    def __visitar_texto(self, nodo_actual):
        # Analiza un nodo de tipo Texto
        nodo_actual.atributos['tipo'] = TipoDatos.TEXTO

    def __visitar_entero(self, nodo_actual):
        # Analiza un nodo de tipo Entero
        nodo_actual.atributos['tipo'] = TipoDatos.número

    def __visitar_flotante(self, nodo_actual):
        # Analiza un nodo de tipo Flotante
        nodo_actual.atributos['tipo'] = TipoDatos.número

    def __visitar_identificador(self, nodo_actual):
        # Identificador ::= [a-z][a-zA-Z0-9]+
        nodo_actual.atributos['tipo'] = TipoDatos.CUALQUIERA

    def obtener_errores(self):
        # Devuelve la lista de errores acumulados durante la visita
        return self.errores


class Verificador:
    def __init__(self, nuevo_asa):
        self.asa = nuevo_asa
        self.tabla_simbolos = TablaSimbolos()
        self.__cargar_ambiente_estandar()
        self.visitador = Visitante(self.tabla_simbolos)

    def imprimir_asa(self):
        # Imprime el árbol de sintaxis abstracta
        if self.asa.raiz is None:
            print([])
        else:
            self.asa.imprimir_preorden()

    def __cargar_ambiente_estandar(self):
        # Carga el ambiente estándar con funciones predefinidas
        funciones_estandar = [
            ('hacer_menjunje', TipoDatos.NINGUNO),
            ('viene_bolita', TipoDatos.TEXTO),
            ('trone', TipoDatos.número),
            ('sueltele', TipoDatos.NINGUNO),
            ('echandi_jimenez', TipoDatos.TEXTO),
            ('verificarNum', TipoDatos.VALOR_VERDAD),
            ('sonnúmeros', TipoDatos.VALOR_VERDAD),
            ('cree_Lista', TipoDatos.LISTA),
            ('jale_lavara', TipoDatos.CUALQUIERA),
            ('metale_lavara', TipoDatos.NINGUNO),
            ('saque_lavara', TipoDatos.NINGUNO)
        ]

        for nombre, tipo in funciones_estandar:
            nodo = NodoÁrbol(TipoNodo.FUNCION, contenido=nombre, atributos={'tipo': tipo})
            self.tabla_simbolos.nuevo_registro(nodo)

    def verificar(self):
        # Inicia la verificación del árbol de sintaxis abstracta
        self.visitador.visitar(self.asa.raiz)
        errores_tabla_simbolos = self.tabla_simbolos.obtener_errores()
        errores_visitante = self.visitador.obtener_errores()
        todos_los_errores = errores_tabla_simbolos + errores_visitante

        if todos_los_errores:
            print("Errores encontrados:")
            for error in todos_los_errores:
                print(error)
        else:
            print("No se encontraron errores.")
