
from utils.árbol import ÁrbolSintáxisAbstracta, NodoÁrbol, TipoNodo 

class VisitantePython:
    
    tabuladores = 0
    errores = []

    def __init__(self):
        # Mapea cada tipo de nodo a su método visitante correspondiente
        self.visitors = {
            TipoNodo.PROGRAMA: self.__visitar_programa,
            TipoNodo.ASIGNACIÓN: self.__visitar_asignación,
            TipoNodo.EXPRESIÓN_MATEMÁTICA: self.__visitar_expresión_matemática,
            TipoNodo.EXPRESIÓN: self.__visitar_expresión,
            TipoNodo.FUNCIÓN: self.__visitar_función,
            TipoNodo.INVOCACIÓN: self.__visitar_invocación,
            TipoNodo.PARÁMETROS_INVOCACIÓN: self.__visitar_parámetros_invocación,
            TipoNodo.PARÁMETROS_FUNCIÓN: self.__visitar_parámetros_función,
            TipoNodo.INSTRUCCIÓN: self.__visitar_instrucción,
            TipoNodo.REPETICIÓN: self.__visitar_repetición,
            TipoNodo.BIFURCACIÓN: self.__visitar_bifurcación,
            TipoNodo.DIAYSI: self.__visitar_diaysi,
            TipoNodo.SINO: self.__visitar_sino,
            TipoNodo.OPERADOR_LÓGICO: self.__visitar_operador,
            TipoNodo.CONDICIÓN: self.__visitar_condición,
            TipoNodo.COMPARACIÓN: self.__visitar_comparación,
            TipoNodo.RETORNO: self.__visitar_retorno,
            TipoNodo.ERROR: self.__visitar_error,
            TipoNodo.PRINCIPAL: self.__visitar_principal,
            TipoNodo.BLOQUE_INSTRUCCIONES: self.__visitar_bloque_instrucciones,
            TipoNodo.OPERADOR: self.__visitar_operador,
            TipoNodo.VALOR_VERDAD: self.__visitar_valor_verdad,
            TipoNodo.COMPARADOR: self.__visitar_comparador,
            TipoNodo.TEXTO: self.__visitar_texto,
            TipoNodo.ENTERO: self.__visitar_entero,
            TipoNodo.FLOTANTE: self.__visitar_flotante,
            TipoNodo.IDENTIFICADOR: self.__visitar_identificador,
            TipoNodo.LISTA: self._visitar_lista,
            TipoNodo.ingreso_LISTA: self._entradaEn_lista,
            TipoNodo.vara_LISTA: self._visitar_varaEn_lista,
            TipoNodo._enLista: self.__visitarExisiste_enLista,  # Corregido para usar __visitarExisiste_enLista
        }

    def visitar(self, nodo: TipoNodo):
        """
        Método principal que redirige la visita según el tipo de nodo.
        """
        visitor = self.visitors.get(nodo.tipo)
        if visitor is not None:
            return visitor(nodo)
        else:
            raise Exception('En realidad nunca va a llegar acá')

    def __visitar_programa(self, nodo_actual):
        """
        Visita un nodo de tipo PROGRAMA.
        Recorre todos los nodos hijos y los visita, uniendo los resultados en una cadena.
        """
        instrucciones = [self.visitar(nodo) for nodo in nodo_actual.nodos]
        return '\n'.join(instrucciones)

    def __visitar_asignación(self, nodo_actual):
        """
        Visita un nodo de tipo ASIGNACIÓN.
        Construye una cadena de asignación con el primer nodo hijo como el nombre de la variable
        y el segundo nodo hijo como el valor a asignar.
        """
        resultado = "{} = {}"
        instrucciones = [self.visitar(nodo) for nodo in nodo_actual.nodos]
        return resultado.format(instrucciones[0], instrucciones[1])

    def __visitar_expresión_matemática(self, nodo_actual):
        """
        Visita un nodo de tipo EXPRESIÓN_MATEMÁTICA.
        Une los resultados de visitar todos los nodos hijos con espacios en blanco.
        """
        instrucciones = [self.visitar(nodo) for nodo in nodo_actual.nodos]
        return ' '.join(instrucciones)

    def __visitar_expresión(self, nodo_actual):
        """
        Visita un nodo de tipo EXPRESIÓN.
        Une los resultados de visitar todos los nodos hijos con espacios en blanco.
        """
        instrucciones = [self.visitar(nodo) for nodo in nodo_actual.nodos]
        return ' '.join(instrucciones)

    def __visitar_función(self, nodo_actual):
        """
        Visita un nodo de tipo FUNCIÓN.
        Construye una cadena de definición de función con el primer nodo hijo como el nombre
        de la función, el segundo nodo hijo como los parámetros y el resto de los nodos hijos
        como el cuerpo de la función.
        """
        resultado = "\ndef {}({}):\n{}"
        instrucciones = [self.visitar(nodo) for nodo in nodo_actual.nodos]
        return resultado.format(instrucciones[0], instrucciones[1], '\n'.join(instrucciones[2]))

    def __visitar_invocación(self, nodo_actual):
        """
        Visita un nodo de tipo INVOCACIÓN.
        Construye una cadena de invocación de función con el primer nodo hijo como el nombre
        de la función y el segundo nodo hijo como los argumentos.
        """
        resultado = "{}({})"
        instrucciones = [self.visitar(nodo) for nodo in nodo_actual.nodos]
        return resultado.format(instrucciones[0], instrucciones[1])

    def __visitar_parámetros_invocación(self, nodo_actual):
        """
        Visita un nodo de tipo PARÁMETROS_INVOCACIÓN.
        Une los resultados de visitar todos los nodos hijos con comas.
        """
        parámetros = [self.visitar(nodo) for nodo in nodo_actual.nodos]
        return ','.join(parámetros)

    def __visitar_parámetros_función(self, nodo_actual):
        """
        Visita un nodo de tipo PARÁMETROS_FUNCIÓN.
        Une los resultados de visitar todos los nodos hijos con comas.
        """
        parámetros = [self.visitar(nodo) for nodo in nodo_actual.nodos]
        return ','.join(parámetros)

    def __visitar_instrucción(self, nodo_actual):
        """
        Visita un nodo de tipo INSTRUCCIÓN.
        Une los resultados de visitar todos los nodos hijos sin separadores.
        """
        valor = [self.visitar(nodo) for nodo in nodo_actual.nodos]
        return ''.join(valor)

    def __visitar_repetición(self, nodo_actual):
        """
        Visita un nodo de tipo REPETICIÓN.
        Construye una cadena de bucle 'while' con el primer nodo hijo como la condición
        y el segundo nodo hijo como el cuerpo del bucle.
        """
        resultado = "while {}:\n{}"
        instrucciones = [self.visitar(nodo) for nodo in nodo_actual.nodos]
        return resultado.format(instrucciones[0], '\n'.join(instrucciones[1]))

    def __visitar_bifurcación(self, nodo_actual):
        """
        Visita un nodo de tipo BIFURCACIÓN.
        Construye una cadena de bifurcación con el primer nodo hijo como la condición
        y el segundo nodo hijo (si existe) como el cuerpo del 'else'.
        """
        resultado = "{}{}"
        instrucciones = [self.visitar(nodo) for nodo in nodo_actual.nodos]
        return resultado.format(instrucciones[0], instrucciones[1] if len(instrucciones) > 1 else '')

    def __visitar_diaysi(self, nodo_actual):
        """
        Visita un nodo de tipo DIAYSI.
        Construye una cadena 'if' o 'if not' según el tipo del primer nodo hijo.
        """
        if nodo_actual.nodos[0].tipo is TipoNodo.NEGACIÓN:
            resultado = "if not {}:\n{}"
            instrucciones = [self.visitar(nodo) for nodo in nodo_actual.nodos[1:]]
            return resultado.format(instrucciones[0], '\n'.join(instrucciones[1]))
        else:
            resultado = "if {}:\n{}"
            instrucciones = [self.visitar(nodo) for nodo in nodo_actual.nodos]
            return resultado.format(instrucciones[0], '\n'.join(instrucciones[1]))

    def __visitar_sino(self, nodo_actual):
        """
        Visita un nodo de tipo SINO.
        Construye una cadena 'else' con el cuerpo correspondiente.
        """
        resultado = "else:\n{}"
        instrucciones = [self.visitar(nodo) for nodo in nodo_actual.nodos]
        return resultado.format('\n'.join(instrucciones))

    def __visitar_condición(self, nodo_actual):
        """
        Visita un nodo de tipo CONDICIÓN.
        Construye una cadena de condición con los nodos hijos.
        """
        resultado = "{} {} {}"
        instrucciones = [self.visitar(nodo) for nodo in nodo_actual.nodos]
        if len(instrucciones) == 1:
            return instrucciones[0]
        else:
            return resultado.format(instrucciones[0], instrucciones[1], instrucciones[2])

    def __visitar_comparación(self, nodo_actual):
        """
        Visita un nodo de tipo COMPARACIÓN.
        Construye una cadena de comparación con los nodos hijos.
        """
        resultado = "{} {} {}"
        varas = [self.visitar(nodo) for nodo in nodo_actual.nodos]
        return resultado.format(varas[0], varas[1], varas[2])

    def __visitar_retorno(self, nodo_actual):
        """
        Visita un nodo de tipo RETORNO.
        Construye una cadena 'return' con el valor correspondiente.
        """
        resultado = "return {}"
        valor = ''.join([self.visitar(nodo) for nodo in nodo_actual.nodos])
        return resultado.format(valor)

    def __visitar_error(self, nodo_actual):
        """
        Visita un nodo de tipo ERROR.
        Construye una cadena de impresión de error en la consola.
        """
        resultado = 'print("\\033[91m", {}, "\\033[0m", file=sys.stderr)'
        valor = self.visitar(nodo_actual.nodos[0])
        valor = valor.replace('"', '\\"')  # Escapa las comillas dobles en el valor
        return resultado.format(f'"{valor}"')

    def __visitar_principal(self, nodo_actual):
        """
        Visita un nodo de tipo PRINCIPAL.
        Construye una cadena de definición de función 'principal'.
        """
        resultado = "\ndef principal():\n{}\n\nif __name__ == '__main__':\n    principal()"
        instrucciones = [self.visitar(nodo) for nodo in nodo_actual.nodos]
        instrucciones_planas = [instruccion if isinstance(instruccion, str) else '\n'.join(instruccion) for instruccion in instrucciones]
        return resultado.format('\n'.join(instrucciones_planas))

    def __visitar_bloque_instrucciones(self, nodo_actual):
        """
        Visita un nodo de tipo BLOQUE_INSTRUCCIONES.
        Añade tabulaciones a cada instrucción del bloque.
        """
        self.tabuladores += 4
        instrucciones = [self.visitar(nodo) for nodo in nodo_actual.nodos]
        instrucciones_tabuladas = [self.__retornar_tabuladores() + instruccion for instruccion in instrucciones]
        self.tabuladores -= 4
        return instrucciones_tabuladas

    def __visitar_operador(self, nodo_actual):
        """
        Visita un nodo de tipo OPERADOR.
        Mapea el contenido del nodo al operador correspondiente.
        """
        operadores = {
            'echele': '+',
            'quitele': '-',
            'chuncherequee': '*',
            'desmadeje': '/'
        }
        return operadores.get(nodo_actual.contenido, '')

    def __visitar_valor_verdad(self, nodo_actual):
        """
        Visita un nodo de tipo VALOR_VERDAD.
        Retorna el contenido del nodo.
        """
        return nodo_actual.contenido

    def __visitar_comparador(self, nodo_actual):
        """
        Visita un nodo de tipo COMPARADOR.
        Mapea el contenido del nodo al comparador correspondiente.
        """
        comparadores = {
            'cañazo': '>',
            'poquitico': '<',
            'misma vara': '==',
            'otra vara': '!=',
            'menos o igualitico': '<=',
            'más o igualitico': '>='
        }
        return comparadores.get(nodo_actual.contenido, '')

    def _visitar_lista(self, nodo):
        """
        Visita un nodo de tipo LISTA.
        Construye una lista con los varas visitados.
        """
        return f"[{', '.join(n.visitar(self) for n in nodo.nodos)}]"

    def _visitar_varaEn_lista(self, nodo):
        """
        Visita un nodo de tipo vara_LISTA.
        Une los varas de la lista con comas.
        """
        return ', '.join(n.visitar(self) for n in nodo.nodos)

    def _entradaEn_lista(self, nodo):
        """
        Visita un nodo de tipo ingreso_LISTA.
        Construye una cadena de ingreso a lista con el nombre de la lista y el índice.
        """
        return f"{nodo.nodos[0].visitar(self)}[{nodo.nodos[1].visitar(self)}]"

    def __visitarExisiste_enLista(self, nodo_actual):
        """
        Visita un nodo de tipo _enLista.
        Construye una cadena 'in' para comprobar si un valor está _enLista de una lista.
        """
        valor = self.visitar(nodo_actual.nodos[0])
        lista = self.visitar(nodo_actual.nodos[1])
        return f"{valor} in {lista}"

    def __visitar_texto(self, nodo_actual):
        """
        Visita un nodo de tipo TEXTO.
        Reemplaza los caracteres '~' por comillas dobles en el contenido del nodo.
        """
        return nodo_actual.contenido.replace('~', '"')

    def __visitar_entero(self, nodo_actual):
        """
        Visita un nodo de tipo ENTERO.
        Retorna el contenido del nodo.
        """
        return nodo_actual.contenido

    def __visitar_flotante(self, nodo_actual):
        """
        Visita un nodo de tipo FLOTANTE.
        Retorna el contenido del nodo.
        """
        return nodo_actual.contenido

    def __visitar_identificador(self, nodo_actual):
        """
        Visita un nodo de tipo IDENTIFICADOR.
        Retorna el contenido del nodo.
        """
        return nodo_actual.contenido

    def __retornar_tabuladores(self):
        """
        Retorna una cadena de espacios según el nivel de tabulación actual.
        """
        return " " * self.tabuladores