# Analizador

Implementa el analizador léxico para el lenguaje Ciruelas e imprime el ASA (Árbol de Sintaxis Abstracta) en preorden en la terminal.

Recibe una lista de componentes léxicos y funciona implementando el patrón visitante.
